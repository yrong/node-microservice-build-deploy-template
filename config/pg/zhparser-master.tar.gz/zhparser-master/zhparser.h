#ifndef ZHPARSER_H 
#define ZHPARSER_H

#ifndef pstrdup
#define pstrdup scws_pstrdup
#endif

#include "scws.h"

#undef pstrdup

#endif
